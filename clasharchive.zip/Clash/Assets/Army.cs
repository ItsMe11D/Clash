﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Army : MonoBehaviour {
    public List<GameObject> members;
}

/*
// Update is called once per frame
void Update()
{

    if (isLeftPlayerTurn)
    {
        bool firstTime = true;

        foreach (var fighter in leftPlayerArmy.members)
        {

            if (firstTime)
            {
                Debug.Log(c);
                c = fighter.GetComponent<Character>();
                firstTime = false;
            }
            consoleText.text = c.charName;
            consoleText.text += "has " + c.movesLeft + "moves left.";

            if (!c.hasGone)
            {

                if (Input.anyKey)
                {
                    if (Input.GetKeyDown(KeyCode.LeftArrow) && c.currentLocation.left != null && c.currentLocation.left.isPassable)
                    {
                        c.transform.position = c.currentLocation.left.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.left;
                        c.movesLeft--;
                        Debug.Log("Down to : " + c.movesLeft);
                    }
                    else if (Input.GetKeyDown(KeyCode.RightArrow) && c.currentLocation.right != null && c.currentLocation.right.isPassable)
                    {
                        c.transform.position = c.currentLocation.right.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.right;
                        c.movesLeft--;
                        Debug.Log("Down to : " + c.movesLeft);
                    }
                    else if (Input.GetKeyDown(KeyCode.UpArrow) && c.currentLocation.above != null && c.currentLocation.above.isPassable)
                    {
                        c.transform.position = c.currentLocation.above.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.above;
                        c.movesLeft--;
                        Debug.Log("Down to : " + c.movesLeft);
                    }
                    else if (Input.GetKeyDown(KeyCode.DownArrow) && c.currentLocation.below != null && c.currentLocation.below.isPassable)
                    {
                        c.transform.position = c.currentLocation.below.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.below;
                        c.movesLeft--;
                        Debug.Log("Down to : " + c.movesLeft);
                    }
                }

                if (c.movesLeft <= 0)
                {
                    c.hasGone = true;
                    firstTime = false;
                }
            }
        }




        //resetting right players army
        isLeftPlayerTurn = false;
        for (int i = 0; i < leftPlayerArmy.Count; i++)
        {                                               //c = currently selected character
            c = leftPlayerArmy[i].GetComponent<Character>();
            c.hasGone = false;
            c.movesLeft = c.movement;
        }
    }
    else
    {
        Character c = rightPlayerArmy[0].GetComponent<Character>();
        bool firstTime = true;
        for (int i = 0; i < leftPlayerArmy.Count;)
        {                                               //c = currently selected character
            if (firstTime)
            {
                c = rightPlayerArmy[i].GetComponent<Character>();
                Debug.Log(c.charName);
                consoleText.text = c.charName;
                consoleText.text += "has " + c.movesLeft + "moves left.";
                firstTime = false;
            }
            if (!c.hasGone)
            {
                consoleText.text += "has " + c.movesLeft + "moves left.";
                if (Input.anyKey)
                {
                    if (Input.GetKeyDown(KeyCode.LeftArrow) && c.currentLocation.left && c.currentLocation.left.isPassable)
                    {
                        c.transform.position = c.currentLocation.left.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.left;
                        c.movesLeft--;
                    }
                    else if (Input.GetKeyDown(KeyCode.RightArrow) && c.currentLocation.right && c.currentLocation.right.isPassable)
                    {
                        c.transform.position = c.currentLocation.right.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.right;
                        c.movesLeft--;
                    }
                    else if (Input.GetKeyDown(KeyCode.UpArrow) && c.currentLocation.above && c.currentLocation.above.isPassable)
                    {
                        c.transform.position = c.currentLocation.above.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.above;
                        c.movesLeft--;
                    }
                    else if (Input.GetKeyDown(KeyCode.DownArrow) && c.currentLocation.below && c.currentLocation.below.isPassable)
                    {
                        c.transform.position = c.currentLocation.below.transform.position + new Vector3(0, 0, -10);
                        c.currentLocation = c.currentLocation.below;
                        c.movesLeft--;
                    }
                }
                if (c.movesLeft <= 0)
                {
                    c.hasGone = true;
                    i++;
                    firstTime = true;
                }
            }

        }//reset all left Army characters heree
        isLeftPlayerTurn = true;
        for (int i = 0; i < leftPlayerArmy.Count; i++)
        {                                               //c = currently selected character
            c = leftPlayerArmy[i].GetComponent<Character>();
            c.hasGone = false;
            c.movesLeft = c.movement;
        }
    }
}
*/
