﻿using UnityEngine;
using System.Collections;

public class BattlefieldCell : MonoBehaviour {
    public BattlefieldCell above, below, left, right;
    public bool isPassable;
    public int xI, yI;
    public Character whosOnThis;

	// Use this for initialization
	void Start () {
        above = GameObject.Find("Cube " + (xI) + "," + (yI - 1))? GameObject.Find("Cube " + (xI) + "," + (yI - 1)).GetComponent<BattlefieldCell>() : null;
        left = GameObject.Find("Cube " + (xI-1) + "," + (yI))? GameObject.Find("Cube " + (xI - 1) + "," + (yI)).GetComponent<BattlefieldCell>() : null;
        right = GameObject.Find("Cube " + (xI+1) + "," + (yI))? GameObject.Find("Cube " + (xI + 1) + "," + (yI)).GetComponent<BattlefieldCell>() : null;
        below = GameObject.Find("Cube " + (xI) + "," + (yI + 1))? GameObject.Find("Cube " + (xI) + "," + (yI + 1)).GetComponent<BattlefieldCell>() : null;
        
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
