﻿using UnityEngine;
using System.Collections;

public class Character : MonoBehaviour {
    public int health;
    public int movement;
    public int attack;
    public int attackRange;
    public int defense;
    public string charName;
    public bool hasGone;
    public BattlefieldCell currentLocation;
    public int movesLeft;


	// Use this for initialization
	void Start () {
        hasGone = false;
        movesLeft = movement;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void isAttacked(Character a_enemy, bool isCounter)
    {
        int damageTaken = a_enemy.attack - this.defense;
        health -= damageTaken;
        if (health <= 0)
        {
            this.Death();
        }
        else if (!isCounter)
        {
            a_enemy.isAttacked(this, true);
        }
    }

    void Death()
    {

    }
}
